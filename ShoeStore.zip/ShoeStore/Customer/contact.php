<?php
include('include/header.php');
?>
    <br>    <br>    <br>
    <center>
    <!--contact area start-->
    <div class="contact_area">
        <div class="container">   
            <div class="row">
                <div class="col-lg-12 col-md-12">
                   <div class="contact_message content">
                        <h1>Contact Us</h1>    
                        <br>
                         <p style="font-weight:bolder; color:darkcyan; font-size:25px;">"Should Be Memorable, Reflect The Brand And Connect With The Audience"</p>
                        <ul>
                            <li><i class="fa fa-fax"></i>  Kuala Lumpur, Malaysia.</li>
                            <li><i class="fa fa-phone"></i> <a href="tel:0(1234)567890">+605-9877565</a></li>
                            <li><i class="fa fa-envelope-o"></i><a href="mailto:admin@gmail.com">admin@gmail.com</a>  </li>
                        </ul>             
                    </div> 
                </div>
            </div>
        </div>    
    </div>
    </center>

    <!--contact area end-->

<?php
include('include/footer.php');

?>